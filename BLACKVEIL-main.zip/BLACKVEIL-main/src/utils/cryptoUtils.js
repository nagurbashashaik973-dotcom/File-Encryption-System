/**
 * client-side encryption/decryption utilities using Web Crypto API (AES-GCM)
 */

// Generate a random 256-bit key for AES-GCM
export async function generateKey() {
    return window.crypto.subtle.generateKey(
        {
            name: "AES-GCM",
            length: 256,
        },
        true, // extractable
        ["encrypt", "decrypt"]
    );
}

// Import a key from base64 string
export async function importKey(base64Key) {
    try {
        const rawKey = Uint8Array.from(atob(base64Key), c => c.charCodeAt(0));
        return window.crypto.subtle.importKey(
            "raw",
            rawKey,
            "AES-GCM",
            true,
            ["encrypt", "decrypt"]
        );
    } catch (e) {
        throw new Error("Invalid key format");
    }
}

// Export key to base64 string
export async function exportKey(key) {
    const exported = await window.crypto.subtle.exportKey("raw", key);
    return btoa(String.fromCharCode(...new Uint8Array(exported)));
}

// Encrypt file content
// Returns { encryptedBlob, iv }
export async function encryptFile(file, key) {
    const iv = window.crypto.getRandomValues(new Uint8Array(12)); // 96-bit IV
    const fileData = await file.arrayBuffer();

    const encryptedContent = await window.crypto.subtle.encrypt(
        {
            name: "AES-GCM",
            iv: iv,
        },
        key,
        fileData
    );

    // Combine IV and encrypted data into a single blob for download?
    // User req: "Display the encryption key... Allow download of the encrypted file."
    // Usually we prefix the IV to the file.

    const combinedData = new Uint8Array(iv.length + encryptedContent.byteLength);
    combinedData.set(iv);
    combinedData.set(new Uint8Array(encryptedContent), iv.length);

    return new Blob([combinedData], { type: "application/octet-stream" });
}

// Decrypt file content
// Expects blob containing IV + Encrypted Data
export async function decryptFile(file, key) {
    const fileData = await file.arrayBuffer();

    const iv = new Uint8Array(fileData.slice(0, 12));
    const ciphertext = fileData.slice(12);

    const decryptedContent = await window.crypto.subtle.decrypt(
        {
            name: "AES-GCM",
            iv: iv,
        },
        key,
        ciphertext
    );

    return new Uint8Array(decryptedContent); // can be converted to text or blob
}
