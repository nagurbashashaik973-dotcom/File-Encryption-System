
import React, { useState } from 'react';
import FileUpload from './components/FileUpload';
import ModeSelector from './components/ModeSelector';
import InfoSection from './components/InfoSection';
import EncryptSection from './components/EncryptSection';
import DecryptSection from './components/DecryptSection';
import TerminalStatus from './components/TerminalStatus';
import MatrixBackground from './components/MatrixBackground';

function App() {
  const [mode, setMode] = useState('encrypt');
  const [selectedFile, setSelectedFile] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isProcessComplete, setIsProcessComplete] = useState(false);

  const handleFileSelect = (file) => {
    setSelectedFile(file);
    setIsProcessComplete(false);
  };

  const handleModeChange = (newMode) => {
    setMode(newMode);
    setSelectedFile(null);
    setIsProcessComplete(false);
  };

  const handleProcessStart = () => {
    setIsProcessing(true);
    setIsProcessComplete(false);
  };

  const handleProcessComplete = () => {
    setIsProcessing(false);
    setIsProcessComplete(true);
  };

  // Callback wrapper to handle timing from child components
  const onStartWrapper = () => {
    handleProcessStart();
    // Simulate process time to match animation (roughly)
    // In a real app, we'd wait for actual completion, but here we want visual sync
    setTimeout(() => {
      handleProcessComplete();
    }, 4000);
  };

  return (
    <>
      <MatrixBackground />
      <div className="app-container">
        <div className="left-column">
          <header className="compact-header">
            <div className="logo-area">
              <img src="black_veil_icon.png" alt="Black Veil Logo" className="app-logo" />
              <div className="title-group">
                <h1>BLACK_VEIL</h1>
                <p className="subtitle">SECURE_PROTOCOL_V1</p>
              </div>
            </div>
          </header>

          <ModeSelector mode={mode} setMode={handleModeChange} />

          <div className="main-controls">
            <FileUpload
              onFileSelect={handleFileSelect}
              selectedFile={selectedFile}
            />

            <div className="action-area">
              {mode === 'encrypt' ? (
                <EncryptSection
                  file={selectedFile}
                  onStart={onStartWrapper}
                  isReady={isProcessComplete}
                />
              ) : (
                <DecryptSection
                  file={selectedFile}
                  onStart={onStartWrapper}
                  isReady={isProcessComplete}
                />
              )}
            </div>
          </div>
        </div>

        <div className="right-column">
          <TerminalStatus
            mode={mode}
            isProcessing={isProcessing}
            isComplete={isProcessComplete}
          />
        </div>
      </div>

      <InfoSection />
    </>
  );
}

export default App;
