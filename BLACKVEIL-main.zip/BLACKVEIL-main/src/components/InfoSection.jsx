import React from 'react';

const InfoSection = () => {
    return (
        <div className="info-section-container">
            <div className="info-block">
                <h3>WHAT IS BLACK VEIL?</h3>
                <p>
                    Black Veil is an advanced, military-grade file encryption protocol designed for absolute data supremacy.
                    Utilizing AES-256 encryption standards wrapped in a stealth interface, it ensures your sensitive assets
                    remain invisible to unauthorized entities. Your data isn't just hidden; it ceases to exist for them.
                </p>
            </div>

            <div className="info-block">
                <h3>SYSTEM INSTRUCTIONS</h3>
                <ol className="instruction-list">
                    <li>
                        <span className="step-marker">01</span>
                        <span><strong>Select Mode:</strong> Toggle the switch to choose ENCRYPT (lock) or DECRYPT (unlock) protocol.</span>
                    </li>
                    <li>
                        <span className="step-marker">02</span>
                        <span><strong>Upload Asset:</strong> Drag & drop your target file into the drop zone area.</span>
                    </li>
                    <li>
                        <span className="step-marker">03</span>
                        <span><strong>Authentication:</strong> Enter your secure key. For decryption, this must match the encryption key exactly.</span>
                    </li>
                    <li>
                        <span className="step-marker">04</span>
                        <span><strong>Execute:</strong> Initiate the process and wait for the terminal to confirm completion.</span>
                    </li>
                </ol>
            </div>
        </div>
    );
};

export default InfoSection;
