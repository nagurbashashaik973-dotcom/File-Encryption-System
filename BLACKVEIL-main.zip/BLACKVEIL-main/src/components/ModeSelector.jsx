import React from 'react';

const ModeSelector = ({ mode, setMode }) => {
    return (
        <div className="mode-selector">
            <div className={`mode-indicator ${mode}`} />
            <button
                className={`mode-btn ${mode === 'encrypt' ? 'active' : ''}`}
                onClick={() => setMode('encrypt')}
            >
                Encrypt
            </button>
            <button
                className={`mode-btn ${mode === 'decrypt' ? 'active' : ''}`}
                onClick={() => setMode('decrypt')}
            >
                Decrypt
            </button>
        </div>
    );
};

export default ModeSelector;
