import React, { useRef } from 'react';

const FileUpload = ({ onFileSelect, selectedFile }) => {
    const fileInputRef = useRef(null);

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            onFileSelect(file);
        }
    };

    return (
        <div className="file-upload-container">
            <div
                className="drop-zone"
                onClick={() => fileInputRef.current.click()}
            >
                <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    // Removed accept attribute to allow all files
                    // accept=".txt,.docx" 
                    style={{ display: 'none' }}
                />
                <p className="upload-text">
                    {selectedFile ? `SELECTED: ${selectedFile.name}` : "CLICK TO UPLOAD ANY FILE"}
                </p>
            </div>
        </div>
    );
};

export default FileUpload;
