import React, { useState } from 'react';
import { importKey, decryptFile } from '../utils/cryptoUtils';

const DecryptSection = ({ file, onStart, isReady }) => {
    const [keyInput, setKeyInput] = useState('');
    const [decryptedBlob, setDecryptedBlob] = useState(null);
    const [error, setError] = useState('');
    const [decryptedFileName, setDecryptedFileName] = useState('');
    const [processing, setProcessing] = useState(false);

    const executeDecryption = async () => {
        if (!file || !keyInput) return;
        setError('');
        setDecryptedBlob(null);

        try {
            const cryptoKey = await importKey(keyInput);
            const decryptedData = await decryptFile(file, cryptoKey);

            let originalName = file.name.replace(/^ENCRYPTED_/, '').replace(/\.enc$/, '');
            if (originalName === file.name) originalName = "DECRYPTED_" + file.name;

            const blob = new Blob([decryptedData], { type: "application/octet-stream" });
            setDecryptedBlob(blob);
            setDecryptedFileName(originalName);
        } catch (err) {
            console.error(err);
            setError("DECRYPTION FAILED: INVALID KEY OR CORRUPTED DATA.");
        }
    };

    const handleDecryptClick = async () => {
        setProcessing(true);
        // Notify parent
        onStart();
        await executeDecryption();
        setProcessing(false);
    };

    const handleDownload = () => {
        if (decryptedBlob) {
            const url = URL.createObjectURL(decryptedBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = decryptedFileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }
    };

    return (
        <div className="section decrypt-section">
            <h3>DECRYPT FILE</h3>
            {file ? (
                <p>TARGET: <strong>{file.name}</strong></p>
            ) : (
                <p className="warning">AWAITING ENCRYPTED PAYLOAD...</p>
            )}

            <div className="input-group">
                <label>DECRYPTION KEY:</label>
                <input
                    type="text"
                    value={keyInput}
                    onChange={(e) => setKeyInput(e.target.value)}
                    placeholder="ENTER KEY HERE"
                    className="key-input"
                />
            </div>

            {!isReady && (
                <button
                    className="action-btn"
                    onClick={handleDecryptClick}
                    disabled={!file || !keyInput || processing}
                >
                    {processing ? "PROCESSING..." : "EXECUTE DECRYPTION"}
                </button>
            )}

            {error && <p className="error">{error}</p>}

            {isReady && decryptedBlob && (
                <div className="result-container success">
                    <h4>DECRYPTION SUCCESSFUL</h4>
                    <button className="download-btn" onClick={handleDownload}>
                        DOWNLOAD DECRYPTED FILE
                    </button>
                </div>
            )}
        </div>
    );
};

export default DecryptSection;
