import React, { useEffect, useState } from 'react';

const CinematicOverlay = ({ isVisible, onComplete, mode = 'encrypt' }) => {
    const [step, setStep] = useState(0);
    const [messages, setMessages] = useState([]);

    useEffect(() => {
        if (isVisible) {
            setStep(0);
            setMessages([]);

            const processSteps = mode === 'encrypt'
                ? [
                    "INITIALIZING SECURE ENVIRONMENT...",
                    "GENERATING 256-BIT AES KEYS...",
                    "OBFUSCATING FILE STRUCTURE...",
                    "ENCRYPTING PAYLOAD...",
                    "VERIFYING INTEGRITY...",
                    "PROCESS COMPLETE."
                ]
                : [
                    "ANALYZING ENCRYPTED ARTIFACT...",
                    "VERIFYING KEY SIGNATURE...",
                    "DECRYPTING LAYERS...",
                    "RECONSTRUCTING DATA...",
                    "PROCESS COMPLETE."
                ];

            let currentStep = 0;
            const interval = setInterval(() => {
                if (currentStep < processSteps.length) {
                    setMessages(prev => [...prev, processSteps[currentStep]]);
                    setStep(currentStep + 1);
                    currentStep++;
                } else {
                    clearInterval(interval);
                    setTimeout(onComplete, 1000);
                }
            }, 800); // 800ms per step

            return () => clearInterval(interval);
        }
    }, [isVisible, mode, onComplete]);

    if (!isVisible) return null;

    return (
        <div className="cinematic-overlay">
            <div className="cinematic-content">
                <div className="logo-placeholder">
                    <div className="spinner-ring"></div>
                </div>
                <h2 className="glitch-text">{mode === 'encrypt' ? 'ENCRYPTION PROTOCOL' : 'DECRYPTION PROTOCOL'}</h2>
                <div className="console-output">
                    {messages.map((msg, index) => (
                        <p key={index} className="fade-in-text">
                            <span className="cursor-prefix">&gt;</span> {msg}
                        </p>
                    ))}
                    <span className="blinking-cursor">_</span>
                </div>
            </div>
        </div>
    );
};

export default CinematicOverlay;
