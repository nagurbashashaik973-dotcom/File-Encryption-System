import React, { useState, useEffect } from 'react';
import { generateKey, exportKey, encryptFile } from '../utils/cryptoUtils';

const EncryptSection = ({ file, onStart, isReady }) => {
    const [key, setKey] = useState('');
    const [encryptedBlob, setEncryptedBlob] = useState(null);
    const [error, setError] = useState('');
    const [processing, setProcessing] = useState(false);

    // Effect to actually perform encryption AFTER cinematic start or when ready
    // However, usually we want to do it in background or wait. 
    // For simplicity, let's trigger it when the user clicks, but show results only after isReady.

    // Revised approach: User clicks -> onStart() (Shows Overlay) -> Overlay finishes -> isReady=true -> We show results.
    // We need to calculate the results either before or during. Let's do it during processing but hide it.

    // Actually, to simulate "processing", we can just generate it instantly (since it's fast for small files) 
    // but only reveal it when `isReady` is true.

    const executeEncryption = async () => {
        if (!file) return;
        setError('');
        setEncryptedBlob(null);
        setKey('');

        try {
            const cryptoKey = await generateKey();
            const exportedKey = await exportKey(cryptoKey);
            const blob = await encryptFile(file, cryptoKey);

            setKey(exportedKey);
            setEncryptedBlob(blob);
        } catch (err) {
            console.error(err);
            setError("Encryption failed.");
        }
    };

    const handleEncryptClick = async () => {
        setProcessing(true);
        // Notify parent to start "cinematic" terminal process
        onStart();

        // Perform actual work
        await executeEncryption();
        setProcessing(false);
    };

    const handleCopyKey = () => {
        navigator.clipboard.writeText(key);
        alert("KEY COPIED TO CLIPBOARD");
    };

    const handleDownload = () => {
        if (encryptedBlob) {
            const url = URL.createObjectURL(encryptedBlob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `ENCRYPTED_${file.name}.enc`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }
    };

    return (
        <div className="section encrypt-section">
            <h3>ENCRYPT FILE</h3>
            {file ? (
                <p>TARGET: <strong>{file.name}</strong></p>
            ) : (
                <p className="warning">AWAITING FILE UPLOAD...</p>
            )}

            {/* Show button if not complete or invalid state */}
            {!isReady && (
                <button
                    className="action-btn"
                    onClick={handleEncryptClick}
                    disabled={!file || processing}
                >
                    {processing ? "PROCESSING..." : "INITIALIZE ENCRYPTION"}
                </button>
            )}

            {error && <p className="error">{error}</p>}

            {isReady && key && (
                <div className="result-container">
                    <h4>ENCRYPTION COMPLETE</h4>
                    <div className="key-display">
                        <p><strong>SECURE KEY (SAVE THIS):</strong></p>
                        <div className="key-box">
                            <input type="text" readOnly value={key} />
                            <button onClick={handleCopyKey}>COPY</button>
                        </div>
                        <p className="warning-text">⚠️ LOSS OF KEY = PERMANENT DATA LOSS</p>
                    </div>

                    {encryptedBlob && (
                        <button className="download-btn" onClick={handleDownload}>
                            DOWNLOAD ENCRYPTED PAYLOAD
                        </button>
                    )}
                </div>
            )}
        </div>
    );
};

export default EncryptSection;
