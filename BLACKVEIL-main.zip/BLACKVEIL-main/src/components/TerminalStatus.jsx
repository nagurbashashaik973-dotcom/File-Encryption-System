import React, { useEffect, useState, useRef } from 'react';

const TerminalStatus = ({ mode, isProcessing, isComplete }) => {
    const [logs, setLogs] = useState([]);
    const terminalBodyRef = useRef(null);

    useEffect(() => {
        if (isProcessing) {
            setLogs([]);
            const processSteps = mode === 'encrypt'
                ? [
                    "INITIALIZING SECURE ENVIRONMENT...",
                    "GENERATING 256-BIT AES KEYS...",
                    "OBFUSCATING FILE STRUCTURE...",
                    "ENCRYPTING PAYLOAD...",
                    "VERIFYING INTEGRITY...",
                    "FINALIZING..."
                ]
                : [
                    "ANALYZING ENCRYPTED ARTIFACT...",
                    "VERIFYING KEY SIGNATURE...",
                    "DECRYPTING LAYERS...",
                    "RECONSTRUCTING DATA...",
                    "FINALIZING..."
                ];

            let currentStep = 0;
            const interval = setInterval(() => {
                if (currentStep < processSteps.length) {
                    setLogs(prev => [...prev, { text: processSteps[currentStep], timestamp: new Date().toLocaleTimeString() }]);
                    currentStep++;
                } else {
                    clearInterval(interval);
                }
            }, 400); // Faster logging for "Jet Speed" feel
            return () => clearInterval(interval);
        } else if (isComplete) {
            setLogs(prev => [...prev, { text: "PROCESS COMPLETE. DATA READY.", timestamp: new Date().toLocaleTimeString() }]);
        } else {
            // Idle state
            setLogs([{ text: "SYSTEM READY. AWAITING INPUT...", timestamp: new Date().toLocaleTimeString() }]);
        }
    }, [isProcessing, isComplete, mode]);

    useEffect(() => {
        if (terminalBodyRef.current) {
            terminalBodyRef.current.scrollTop = terminalBodyRef.current.scrollHeight;
        }
    }, [logs]);

    return (
        <div className="terminal-container">
            <div className="terminal-header">
                <span className="terminal-title">STATUS_LOG // {mode.toUpperCase()}</span>
                <div className="terminal-controls">
                    <span className="control red"></span>
                    <span className="control yellow"></span>
                    <span className="control green"></span>
                </div>
            </div>
            <div className="terminal-body" ref={terminalBodyRef}>
                <div className="scanline">
                    {logs.map((log, index) => (
                        <div key={index} className="log-entry">
                            <span className="log-time">[{log.timestamp}]</span>
                            <span className="log-text">{log.text}</span>
                        </div>
                    ))}
                    {isProcessing && <div className="loading-cursor">_</div>}
                </div>
            </div>
        </div>
    );
};

export default TerminalStatus;
