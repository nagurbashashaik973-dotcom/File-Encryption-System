# SecureVault: Client-Side File Encryption Tool

A secure, client-side web application built with React that allows users to encrypt and decrypt text-based files (.txt and .docx) entirely within the browser.

**Privacy Note:** All encryption and decryption operations occur locally on your device. No data is ever sent to a server.

## Features

- **Local Encryption:** Uses AES-GCM (256-bit) via the Web Crypto API.
- **No Backend:** Zero server-side storage or processing.
- **Secure Key Generation:** Unique keys generated for each encryption session.
- **File Support:** Supports `.txt` and `.docx` files.
- **Clean UI:** Responsive and easy-to-use interface.

## How to Use

### Encrypt Mode
1. Select "Encrypt" mode.
2. Upload a `.txt` or `.docx` file.
3. Click "Generate Key & Encrypt".
4. **Copy the generated Security Key.** (Important: You cannot recover the file without this key!)
5. Download the encrypted file.

### Decrypt Mode
1. Select "Decrypt" mode.
2. Upload the encrypted file (usually ends in `.enc`).
3. Paste the Security Key you saved earlier.
4. Click "Decrypt File".
5. Download the decrypted file.

## Security Design

- **Algorithm:** AES-GCM (Advanced Encryption Standard in Galois/Counter Mode).
- **Key Management:** Keys are generated securely in the browser and displayed to the user. The application DOES NOT store keys.
- **Data Privacy:** Files are processed in memory and never transmitted over the network.

## Limitations

- **Large Files:** Processing very large files may affect browser performance or crash the tab due to memory limits, as files are loaded into memory.
- **File Types:** restricted to `.txt` and `.docx` for this version.
- **Key Recovery:** There is NO "Forgot Password" feature. If you lose the key, the data is permanently lost.
- **Browser Security:** The security of the encryption depends on the security of the client browser environment.

## Running Locally

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development server:
   ```bash
   npm run dev
   ```

3. Open the browser at the provided URL (usually `http://localhost:5173`).
